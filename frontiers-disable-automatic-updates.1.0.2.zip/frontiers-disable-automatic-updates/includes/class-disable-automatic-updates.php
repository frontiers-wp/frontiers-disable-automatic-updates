<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly
/**
 * The class responsible for orchestrating the actions and filters of the core plugin.
 */
class Frontiers_Disable_Automatic_Updates {

    protected $loader;
    protected $plugin_name;
    protected $version;

    public function __construct() {
        $this->version = defined('FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION') ? FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION : '1.0.2';
        $this->plugin_name = 'frontiers-disable-automatic-updates';

        $this->frontiers_disable_automatic_updates_load_dependencies();
        $this->frontiers_disable_automatic_updates_setup_global_filters();
        $this->frontiers_disable_automatic_updates_setup_admin_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     */
    private function frontiers_disable_automatic_updates_load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-disable-automatic-updates-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-disable-automatic-updates-public.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-disable-automatic-updates-admin.php';
        $this->loader = new Frontiers_Disable_Automatic_Updates_Loader();
    }

    /**
     * Intercept update processes based on user setting dashboard preferences.
     */
    private function frontiers_disable_automatic_updates_setup_global_filters() {
        $options = get_option('frontiers_disable_automatic_updates_settings');

        // Plugin Restrictions
        if (!empty($options['disable_plugins'])) {
            add_filter('auto_update_plugin', '__return_false', 999);
            add_filter('auto_plugin_update_send_email', '__return_false', 999);
        }

        // Theme Restrictions
        if (!empty($options['disable_themes'])) {
            add_filter('auto_update_theme', '__return_false', 999);
            add_filter('core_update_skip_new_bundled', '__return_true', 999);
            add_filter('auto_theme_update_send_email', '__return_false', 999);
        }

        // Core Engine Restrictions
        if (!empty($options['disable_core'])) {
            add_filter('auto_update_core', '__return_false', 999);
            add_filter('wp_auto_update_core', '__return_false', 999);
            add_filter('auto_core_update_send_email', '__return_false', 999);
        }

        // Translation Restrictions
        if (!empty($options['disable_translations'])) {
            add_filter('auto_update_translation', '__return_false', 999);
        }
    }

    /**
     * Connect our modular settings page configuration to the boilerplate loader.
     */
    private function frontiers_disable_automatic_updates_setup_admin_hooks() {
        $plugin_admin = new Frontiers_Disable_Automatic_Updates_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
        $this->loader->add_action('admin_init', $plugin_admin, 'register_settings');
    }

    public function run() {
        $this->loader->run();
    }

    public function get_plugin_name() {
        return $this->plugin_name;
    }

    public function get_loader() {
        return $this->loader;
    }

    public function get_version() {
        return $this->version;
    }
}

// Initialize and execute the instance safely
$frontiers_disable_automatic_updates = new Frontiers_Disable_Automatic_Updates();