<?php
/**
 *
 * @link              https://github.com/frontiers-wp/frontiers-disable-automatic-updates
 * @since             1.0.0
 * @package           Frontiers_Disable_Automatic_Updates
 * @Frontiers
 *
 * @wordpress-plugin
 * Plugin Name:       Frontiers Disable Automatic Updates
 * Plugin URI:        https://github.com/frontiers-wp/frontiers-disable-automatic-updates
 * Description:       Disables WordPress automatic updates for plugins, themes, and core.
 * Version:           1.0.1
 * Author:            Edwin Bekedam
 * Author URI:        https://github.com/frontiers-wp/frontiers-disable-automatic-updates/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       frontiers-disable-automatic-updates
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 */
if (! defined( 'FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION' ) ) {
    define( 'FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION', '1.0.1' );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-disable-automatic-updates-activator.php
 */
function frontiers_disable_automatic_updates_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-disable-automatic-updates-activator.php';
	Frontiers_Disable_Automatic_Updates_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-disable-automatic-updates-deactivator.php
 */
function frontiers_disable_automatic_updates_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-disable-automatic-updates-deactivator.php';
	Frontiers_Disable_Automatic_Updates_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'frontiers_disable_automatic_updates_activate' );
register_deactivation_hook( __FILE__, 'frontiers_disable_automatic_updates_deactivate' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-disable-automatic-updates.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function Frontiers_disable_automatic_updates_run() {

	$plugin = new Frontiers_Disable_Automatic_Updates();
	$plugin->run();

}
Frontiers_disable_automatic_updates_run();
