<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Handles the admin dashboard settings menu and fields.
 */
class Frontiers_Disable_Automatic_Updates_Admin {

    private $plugin_name;
    private $version;
    private $option_name = 'frontiers_auto_update_settings';

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    // Add options page to the Settings sidebar menu
    public function add_plugin_admin_menu() {
        add_options_page(
            'Disable Auto Updates Settings',
            'Disable Auto Updates',
            'manage_options',
            $this->plugin_name,
            array( $this, 'display_plugin_admin_page' )
        );
    }

    // Register setting fields and sections
    public function register_settings() {
        register_setting( $this->option_name, $this->option_name, array( $this, 'sanitize_settings' ) );

        add_settings_section(
            'frontiers_main_section',
            'Disable Automatic Updates Settings',
            '__return_false',
            $this->plugin_name
        );

        $fields = array(
            'disable_plugins'      => 'Disable Plugins Auto-Updates',
            'disable_themes'       => 'Disable Themes Auto-Updates',
            'disable_core'         => 'Disable WordPress Core Auto-Updates',
            'disable_translations' => 'Disable Translation Auto-Updates',
        );

        foreach ( $fields as $key => $label ) {
            add_settings_field(
                $key,
                $label,
                array( $this, 'render_checkbox' ),
                $this->plugin_name,
                'frontiers_main_section',
                array( 'field' => $key )
            );
        }
    }

    public function sanitize_settings( $input ) {
        $sanitized = array();
        $fields = array( 'disable_plugins', 'disable_themes', 'disable_core', 'disable_translations' );
        foreach ( $fields as $field ) {
            $sanitized[$field] = isset( $input[$field] ) ? 1 : 0;
        }
        return $sanitized;
    }

    public function render_checkbox( $args ) {
        $options = get_option( $this->option_name );
        $field   = $args['field'];
        $value   = isset( $options[$field] ) ? $options[$field] : 0;
        
        echo '<input type="checkbox" name="' . esc_attr( $this->option_name . '[' . $field . ']' ) . '" value="1" ' . checked( 1, $value, false ) . ' />';
    }

    // Render the configuration HTML layout
    public function display_plugin_admin_page() {
        ?>
        <div class="wrap">
            <h2><?php echo esc_html( get_admin_page_title() ); ?></h2>
            <form method="post" action="options.php">
                <?php
                settings_fields( $this->option_name );
                do_settings_sections( $this->plugin_name );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}