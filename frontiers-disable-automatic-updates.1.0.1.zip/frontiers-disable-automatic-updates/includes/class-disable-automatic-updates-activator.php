<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.1
 * @package    Disable_Automatic_Updates
 * @subpackage Disable_Automatic_Updates/includes
 * @author     Edwin Bekedam <wordpress@bekamhealing.com>
 */
class Frontiers_Disable_Automatic_Updates_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
