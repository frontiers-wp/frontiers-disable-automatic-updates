<?php if (!defined('ABSPATH')) die();

use Frontiers\frontiers_Disable_Automatic_Updates\Plugin;

function Frontiers_Disable_Automatic_Updates_nonce_field(){
	Plugin::instance()->nonceField();
}