<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @link       https://github.com/frontiers-wp/frontiers-disable-automatic-updates
 * @since      1.0.0
 *
 * @package    Frontiers_Disable_Automatic_Updates
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove Option on uninstalling/deleting the Plugin.
 */
function frontiers_hide_author_plugin_version_uninstall() {
	delete_option( 'Frontiers_Disable_Automatic_Updates_plugin_version' );
}

/**
 * Remove Fields on uninstalling/deleting the Plugin.
 */
delete_option('Frontiers_Disable_Automatic_Updates_plugin_fields');