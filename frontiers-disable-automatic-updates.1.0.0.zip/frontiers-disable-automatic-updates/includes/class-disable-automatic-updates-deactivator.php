<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Disable_Automatic_Updates
 * @subpackage Disable_Automatic_Updates/includes
 * @author     Edwin Bekedam <wordpress@bekamhealing.com>
 */
class Frontiers_Disable_Automatic_Updates_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
