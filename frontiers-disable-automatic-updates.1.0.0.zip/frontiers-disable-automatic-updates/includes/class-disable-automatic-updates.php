<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Disable_Automatic_Updates
 * @subpackage Disable_Automatic_Updates/includes
 * @author     Edwin Bekedam <wordpress@bekamhealing.com>
 */
class Frontiers_Disable_Automatic_Updates {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Disable_Automatic_Updates_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->version = defined('FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION') ? FRONTIERS_DISABLE_AUTOMATIC_UPDATES_VERSION : '1.0.0';
        $this->plugin_name = 'frontiers-disable-automatic-updates';
        $this->load_dependencies();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        // The class responsible for orchestrating the actions and filters of the core plugin.
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-disable-automatic-updates-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-disable-automatic-updates-public.php';
        $this->loader = new Frontiers_Disable_Automatic_Updates_Loader();
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Disable_Automatic_Updates_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

    /**
     * Disables WordPress automatic updates for plugins, themes, and core.
     * Hooks into WordPress filters to prevent automatic updates.
     */
    public function frontiers_disable_automatic_updates() {
        // Prevent all plugin updates from being automatically installed
        add_filter('auto_update_plugin', '__return_false');
        // Disable plugins auto-update email notifications.
        add_filter('auto_plugin_update_send_email', '__return_false');
        // Prevent all theme updates from being automatically installed
        add_filter('auto_update_theme', '__return_false');
        add_filter('core_update_skip_new_bundled', '__return_true');
        // Disable themes auto-update email notifications.
        add_filter('auto_theme_update_send_email', '__return_false');
        // Prevent WordPress core updates
        add_filter('auto_update_core', '__return_false');
        // Disable core auto-update email notifications.
        add_filter('auto_core_update_send_email', '__return_false');
        // Disable automatic updates for translations
        add_filter('auto_update_translation', '__return_false');
    }

    /**
     * Disables automatic WordPress core updates for a specific user by setting a global constant.
     *
     * @param WP_User|null $user The user object to check capabilities for.
     */
    public function frontiers_disable_automatic_core_updates($user = null) {
        if ($user !== null && isset($user->allcaps['auto_update_core']) && $user->allcaps['auto_update_core']) {
            if (!defined('FRONTIERS_WP_AUTO_UPDATE_CORE')) {
                define('FRONTIERS_WP_AUTO_UPDATE_CORE', false);
            }
        }
    }
}

// Initialize the class
$frontiers_disable_automatic_updates = new Frontiers_Disable_Automatic_Updates();

// Hook the main update disable function to WordPress initialization
add_action('init', array($frontiers_disable_automatic_updates, 'frontiers_disable_automatic_updates'));

// Hook the core update disable function to admin initialization
add_action('admin_init', array($frontiers_disable_automatic_updates, 'frontiers_disable_automatic_core_updates'));